# __init__.py
from .encoder import encode

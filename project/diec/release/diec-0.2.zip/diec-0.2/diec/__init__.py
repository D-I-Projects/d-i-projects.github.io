# __init__.py
from .encoder import ecode

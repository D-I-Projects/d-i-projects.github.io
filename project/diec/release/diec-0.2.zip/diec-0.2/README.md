# Diec

A tool that encodes text and give out a key, that you can decode with this program too!

## Installation

```bash
pip install diec
```

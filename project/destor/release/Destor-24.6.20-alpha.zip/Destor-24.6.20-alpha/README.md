<div align="center">
  
# Destor Alpha

*Continuing (https://github.com/Ivole32/Server-Builder / @ivole32)*

Next version is going to be released soon!*

[![GitHub release](https://img.shields.io/github/release/wfxey/Destor?include_prereleases=&sort=semver&color=blue)](https://github.com/wfxey/Destor/releases/)
[![License](https://img.shields.io/badge/License-MIT-blue)](#license)
[![DevSkim](https://github.com/wfxey/Destor/actions/workflows/devskim.yml/badge.svg)](https://github.com/wfxey/Destor/actions/workflows/devskim.yml)
[![issues - Destor](https://img.shields.io/github/issues/wfxey/Destor)](https://github.com/wfxey/Destor/issues)

</div>

## Description

This os only the alpha channel it just contains the newest version of the progranm but isnt really released yet. Its not made for ordinary use just for developers.

## Minecraft's EULA

With downloading our program you agree to Minecraft's EULA (https://www.minecraft.net/en-us/eula).
In the program itself we will ask you again if your accepting Minecraft's EULA, without accepting theres no way to launch the server.jar file because its a software provided by Minecraft.

## License

Released under [MIT](/LICENSE) by D&I Projects ([@wfxey](https://github.com/wfxey) and [@ivole32](https://github.com/ivole32))

## Discord
![Discord Banner](https://discord.com/api/guilds/1230908371490570314/widget.png?style=banner2)

<div align="center">
  
# Destor Beta

*Continuing (https://github.com/Ivole32/Server-Builder / @ivole32)*

*v24.6.16 / 16.06.24 is going to be released soon!*

[![GitHub release](https://img.shields.io/github/release/wfxey/Destor?include_prereleases=&sort=semver&color=blue)](https://github.com/wfxey/Destor/releases/)
[![License](https://img.shields.io/badge/License-MIT-blue)](#license)
[![DevSkim](https://github.com/wfxey/Destor/actions/workflows/devskim.yml/badge.svg)](https://github.com/wfxey/Destor/actions/workflows/devskim.yml)
[![issues - Destor](https://img.shields.io/github/issues/wfxey/Destor)](https://github.com/wfxey/Destor/issues)

</div>

## Description

<img src="https://raw.githubusercontent.com/wfxey/wfxey/main/Picture.png">

*Only beta fotage*

**Destor is Minecraft Server Management program that has a modern design. Its our first project and currently our only one too.**

## Beta

The program is bigger than 25MB so you can install the Installer here : https://drive.google.com/file/d/1AHNyk49kKk9JV5sjvfIEBN10aMCdOa_c/view?usp=sharing

## Our plans in the future
We want to work on bigger Projects as this one. We've got many ideas and are creative but we are currently not able to make them happen.

## License

Released under [MIT](/LICENSE) by D&I Projects ([@wfxey](https://github.com/wfxey) and [@ivole32](https://github.com/ivole32))

## Discord
![Discord Banner](https://discord.com/api/guilds/1230908371490570314/widget.png?style=banner2)
